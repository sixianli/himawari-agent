import { once } from "node:events";
import { createServer } from "node:http";
import { afterEach, describe, expect, it, vi } from "vitest";

const fixture = vi.hoisted(() => ({ url: "", sends: 0 }));
// Only substitute the external Exa/proxy transport. The installed MCP client,
// request encoding, response parsing and application retry policy remain real.
vi.mock("undici", () => ({
  ProxyAgent: class {
    async close() {}
  },
  fetch: async (_url: string, init: RequestInit & { dispatcher?: unknown }) => {
    fixture.sends++;
    const { dispatcher, ...request } = init;
    void dispatcher;
    return globalThis.fetch(fixture.url, request);
  },
}));

import { ExaPublicSearchAdapter } from "../../packages/platform-node/src/exa-public-search.js";

afterEach(() => vi.unstubAllEnvs());

describe("fixed readonly search with installed MCP transport", () => {
  it.each([503, 403])(
    "handles HTTP %s without replaying session initialization",
    async (status) => {
      const calls: Array<{ method: string; params?: { name?: string; arguments?: unknown } }> = [];
      let searches = 0;
      const server = createServer((request, response) => {
        void (async () => {
          const chunks = [];
          for await (const chunk of request) chunks.push(chunk);
          const message = JSON.parse(Buffer.concat(chunks).toString());
          calls.push(message);
          if (message.method === "notifications/initialized") {
            response.writeHead(202).end();
            return;
          }
          if (message.method === "tools/call" && ++searches === 1) {
            response.writeHead(status).end("provider unavailable");
            return;
          }
          const result =
            message.method === "initialize"
              ? {
                  protocolVersion: message.params.protocolVersion,
                  capabilities: { tools: {} },
                  serverInfo: { name: "readonly-fixture", version: "1" },
                }
              : {
                  content: [
                    {
                      type: "text",
                      text: "Title: Fixture source\nURL: https://example.test/read\nHighlights:\nFixture answer",
                    },
                  ],
                };
          response
            .writeHead(200, { "content-type": "application/json" })
            .end(JSON.stringify({ jsonrpc: "2.0", id: message.id, result }));
        })().catch(() => response.writeHead(500).end());
      });
      server.listen(0, "127.0.0.1");
      await once(server, "listening");
      const address = server.address();
      if (!address || typeof address === "string") throw new Error("fixture listener missing");
      fixture.url = `http://127.0.0.1:${address.port}/mcp`;
      fixture.sends = 0;
      vi.stubEnv("HTTPS_PROXY", "http://fixture:fixture@127.0.0.1:4321");
      try {
        const result = new ExaPublicSearchAdapter().search({ query: "readonly fixture", limit: 1 });
        if (status === 503)
          await expect(result).resolves.toMatchObject([
            { title: "Fixture source", url: "https://example.test/read" },
          ]);
        else await expect(result).rejects.toThrow();
        expect(calls.filter(({ method }) => method === "initialize")).toHaveLength(1);
        const tools = calls.filter(({ method }) => method === "tools/call");
        expect(tools).toHaveLength(status === 503 ? 2 : 1);
        expect(tools[0]?.params).toMatchObject({
          name: "web_search_exa",
          arguments: { query: "readonly fixture", numResults: 1 },
        });
        if (status === 503) expect(tools[1]).toEqual(tools[0]);
      } finally {
        server.closeAllConnections();
        await new Promise<void>((resolve, reject) =>
          server.close((error) => (error ? reject(error) : resolve())),
        );
      }
    },
  );
});
