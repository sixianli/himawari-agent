import { mkdtemp, mkdir, realpath, rm } from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import {validateJobHostControlBinding} from '/Users/triggerjames/Documents/sxl_code_work_space/himawari-agent/dist/node-runtime/node_modules/@himawari-agent/runtime-sandbox/dist/job-host-control.js';
for (const prefix of [path.join(tmpdir(),'himawari-sqlite-capability-invocation-'),'/tmp/h-qh-']) {
 const base=await realpath(await mkdtemp(prefix));
 try {
  const directory=path.join(base,'live-private','control-12345678901234567890');
  await mkdir(directory,{recursive:true,mode:0o700});
  try { await validateJobHostControlBinding({directory,token:'a'.repeat(64),sessionId:randomUUID(),jobId:'probe',attemptId:'probe'}); console.log({socketBytes:Buffer.byteLength(path.join(directory,'control.sock')),result:'passed'}); }
  catch(e) {console.log({socketBytes:Buffer.byteLength(path.join(directory,'control.sock')),error:e.message});}
 } finally {await rm(base,{recursive:true,force:true});}
}
