import { mkdtemp, mkdir, realpath, rm } from 'node:fs/promises';
import path from 'node:path';
import { prepareJobPolicy } from '/Users/triggerjames/Documents/sxl_code_work_space/himawari-agent/dist/node-runtime/node_modules/@himawari-agent/runtime-sandbox/dist/job-policy.js';
const base = await realpath(await mkdtemp('/tmp/h-policy-'));
try {
 const workspace=path.join(base,'workspace'); const privateRoot=path.join(base,'private');
 await Promise.all([workspace,privateRoot].map(p=>mkdir(p,{mode:0o700})));
 await prepareJobPolicy({workspace,privateRoot,jobId:'probe',writable:true,readOnlyToolchainPaths:await Promise.all(['/Users/triggerjames/Documents/sxl_code_work_space/himawari-agent/dist/node-runtime','/bin','/usr/bin','/usr/lib','/System','/dev',process.execPath].map(p=>realpath(p))),protectedPaths:['.env','.git','.himawari-trash'].map(p=>path.join(workspace,p)),allowedDomains:[]});
 console.log('policy passed');
} finally {await rm(base,{recursive:true,force:true});}
