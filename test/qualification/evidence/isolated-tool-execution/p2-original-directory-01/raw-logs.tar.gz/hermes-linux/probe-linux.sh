#!/bin/bash
set -u
S=$1; U=$2
IMG=docker.io/library/busybox@sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e
rm -rf "$S"; mkdir -p "$S/root/sub" "$S/sibling" "$S/mask/emptydir"
echo SECRET > "$S/root/.env"; echo SIBLING > "$S/sibling/secret"; : > "$S/mask/empty"; chmod 444 "$S/mask/empty"; chmod 555 "$S/mask/emptydir"
mkdir -p "$S/root/.ssh"; echo KEY > "$S/root/.ssh/id_ed25519"
(cd "$S/root" && python3 -c "import socket;s=socket.socket(socket.AF_UNIX);s.bind('app.sock');s.listen(1);import time;time.sleep(20)" ) &
sleep 1
ln -s "$S/sibling/secret" "$S/root/abs-link"; ln -s ../sibling/secret "$S/root/rel-link"
docker run --name probe-p2b --network none --user "$U" --read-only --cap-drop ALL --security-opt no-new-privileges=true --label io.himawari.environment.run=probe-p2b \
 --mount "type=bind,source=$S/root,target=/w" \
 --mount "type=bind,source=$S/mask/empty,target=/w/.env,readonly" \
 --mount "type=bind,source=$S/mask/emptydir,target=/w/.ssh,readonly" \
 --mount "type=bind,source=$S/mask/empty,target=/w/app.sock,readonly" \
 $IMG sh -c 'echo "env=[$(cat /w/.env)]"; echo "ssh=[$(ls -la /w/.ssh | tr "\n" " ")]"; ls -lan /w; echo "abs=[$(cat /w/abs-link 2>&1)]"; echo "rel=[$(cat /w/rel-link 2>&1)]"; echo w > /w/written-by-task && echo write=ok; rm /w/.env 2>&1; mv /w/.env /w/x 2>&1; rm -rf /w/.ssh 2>&1; echo "sock=[$(ls -la /w/app.sock)]"; echo "nc=[$(echo hi | nc -U /w/app.sock 2>&1)]"'
echo "exit=$?"
docker inspect --format '{{json .HostConfig.Mounts}}' probe-p2b; echo; docker inspect --format '{{json .Mounts}}' probe-p2b; echo; docker inspect --format '{{json .HostConfig.Binds}}' probe-p2b; echo
docker rm probe-p2b >/dev/null
echo "host .env: $(cat $S/root/.env) ssh: $(cat $S/root/.ssh/id_ed25519)"; ls -lan "$S/root"
wait
