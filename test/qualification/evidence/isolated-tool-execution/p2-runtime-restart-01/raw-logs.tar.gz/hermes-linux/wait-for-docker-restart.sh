#!/bin/sh
before=$(systemctl show docker -p ActiveEnterTimestamp --value)
echo "READY_FOR_RUNTIME_RESTART docker started at: $before" > /data/himawari-p2-20260925-01/restart-evidence/ready.txt
until [ "$(systemctl show docker -p ActiveEnterTimestamp --value)" != "$before" ] && docker info >/dev/null 2>&1; do sleep 2; done
echo "docker restarted at: $(systemctl show docker -p ActiveEnterTimestamp --value)" >> /data/himawari-p2-20260925-01/restart-evidence/ready.txt
