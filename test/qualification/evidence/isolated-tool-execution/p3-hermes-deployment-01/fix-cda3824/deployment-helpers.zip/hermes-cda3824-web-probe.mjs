import assert from "node:assert/strict";
import { readFile, realpath, lstat, readdir } from "node:fs/promises";
import { createHash } from "node:crypto";
import { hostname } from "node:os";
const root = "/data/hermes/himawari/releases/2026-09-11-control-center/share/control-center";
const files = {
  "index.html": "7d8cc40efe0af3c7bd2514c76a4f99d782788014f2aa23f6547d5a9cdc78839e",
  "assets/en-CxQbua-Q.js": "68f5621f1ff742aca8fff3841fae192114c166d3df07ac220ed270a024a6310e",
  "assets/ja-C00FhVI_.js": "a8c89cdbc5e597ff339dd5aa4883630a9885ade39abfd16be17927b7401a5459",
  "assets/index-BsSfaQql.js": "78bb3fd92363df418c224887358dec47929b527ff5799afe1e687396309b9b67",
  "assets/index-CsVKJtvP.css": "649774a226310e744a91370d169f47d0605a393c6537b91f27b06a557614dd56",
  "assets/ja-D5KqAxZE.js": "d7f148172d991b846c5eba3d67feed6bfd32a0e791c36afcc4fe70b92aba585f",
  "assets/index-Dan9HZR8.js": "e8edc904f2b108ee90bb56076f7aff4ffb01077805cd5b6e477ab276c07064af",
  "assets/ja-C8rKgC1Y.js": "a7a07b2f5a31ab6a0cf4c61f227f7ebfe509626907d4fa975748840236afe467",
  "assets/index-BYZ3m8Wo.js": "48fdaa52df1bd1aa7aa9b87d72d498514952c620637924bf37785ecd7b8497c0",
  "assets/index-Dd9xvto3.css": "a2ee8a592b96fdd342049359c2d54129e99c9cf663c8ba3bb05382af790ed5cc",
  "assets/index-CjlRox69.js": "f2ec6343bc85525476be652b7167ea3ea65027d0bbf5a98cd87cf25a010fd3f0",
  "assets/index-DYMewOjF.js": "476ce27d97e5a2f562170588850c893d6d2345b273fe6927e15874e4e042e9d9",
  "assets/ja-CQtdDkYi.js": "c96a4ab39ad31f89fd4fca914cdab9ec5e6484a487309a0c295c9563af4ac0db",
  "assets/ja-CqchQ0W_.js": "f1d13d52c05cdb027902ef9ec93c3c3390c024386c3b8e11f7f795e7dd557965",
  "assets/ja-CHXSs9bO.js": "7cc4a6da8ec7a79acd36133baaa031f527bbb70341fd7aa179c1759ff0e0f50e",
  "assets/index-Bc85Smkr.js": "6409f80b2cb0e7ab489eec07a197d867c1eff3264c15dfb68e258bdf9bc24c3f",
  "assets/index-B0tvWnCd.css": "544bc17d534739adfcca187359cc6f4f4dc816d4d0be48060dfc113ae11f65ff",
  "assets/en-CGguOQtR.js": "c6f00c1112144d2feab0fd64ae19c1b26adf161f778fd6025d0349e42aebd695",
  "assets/index-BoHGHZyl.css": "c02911a8b4dbe990aa39866b0218c01bbdf932bfd7dea287b971d90b160d1cd0",
  "assets/logo-symbol-light-DDULTiXD.png": "62ae5ef7b6cf6fb98cea007bfaba986d9b62f2745b7a579c26977b4ecc11015b",
  "assets/en-b725_cvt.js": "e453f981de9bf7a5ac6dcae050bdff21fbfeefcb0f13f00dd3ca5463f24f47a8",
  "assets/en-aqhV8Uwo.js": "4c856dc0ed25d448e72435bdbf8b645e9a046b201cbec253f04789ab43851841",
  "assets/index-C_Fokyft.js": "9b1452f092d852d1dd70ef18807670ded2b0df075e882ef5161c211de7b2bc62",
  "assets/en-rAeIA1Za.js": "5b14f18facc1c5acd646084457a59f9a2f393c6ff3674044cecd16e832822bd5",
  "assets/en-D9owTKQ-.js": "ef382706a4f5cbec51958ee3c01e550276149cd73148db0b25346449014e68b1",
  "assets/index-UXZvZ-tf.css": "b49b3fa68791cd0f0eb60a70308844b91593e404082555754414170b80f06e92"
};
assert.equal(hostname(), "hermes-home");
assert.equal(process.getuid(), 998);
assert.equal(process.argv.length, 2);
assert.equal(await realpath(root), root);
async function walk(directory, relative = "") {
  const result = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const name = relative + entry.name,
      full = directory + "/" + entry.name;
    assert(!entry.isSymbolicLink());
    if (entry.isDirectory()) result.push(...(await walk(full, name + "/")));
    else {
      assert(entry.isFile());
      result.push(name);
    }
  }
  return result.sort();
}
assert.deepEqual(await walk(root), Object.keys(files).sort());
for (const [name, digest] of Object.entries(files)) {
  const p = root + "/" + name,
    info = await lstat(p);
  assert.equal(await realpath(p), p);
  assert(info.isFile() && info.uid === 0 && info.nlink === 1 && !(info.mode & 0o022));
  assert.equal(
    createHash("sha256")
      .update(await readFile(p))
      .digest("hex"),
    digest,
  );
}
const html = await readFile(root + "/index.html", "utf8");
for (const match of html.matchAll(/(?:src|href)="(\/[^"?#]+)"/g)) assert(files[match[1].slice(1)]);
console.log(
  JSON.stringify({
    passed: true,
    runtimeUid: process.getuid(),
    staticFiles: Object.keys(files).length,
  }),
);
