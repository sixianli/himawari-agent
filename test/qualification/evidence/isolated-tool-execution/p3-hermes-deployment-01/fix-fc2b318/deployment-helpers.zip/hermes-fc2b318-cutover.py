#!/usr/bin/python3
"""Same-schema cutover from ddbdac7 to fc2b318: verified backup, installation switch, restart; no migration and no deletion."""
import fcntl,hashlib,json,os,pathlib,re,shutil,socket,sqlite3,stat,subprocess,sys,tempfile,time
R=pathlib.Path('/data/hermes/himawari')
HERE=pathlib.Path(__file__).resolve().parent
Q=R/'qualifications/2026-09-28-fc2b318-installation'
W=R/'qualifications/2026-09-28-fc2b318-cutover'
CURRENT=R/'releases/2026-09-11-control-center'
CANDIDATE=pathlib.Path('/opt/himawari/releases/2026-09-28-fc2b318')
RUNTIME=CURRENT/'lib/himawari-agent'
CONFIG=R/'config/production.json'
STATE=R/'state'
PREPARED=STATE/'deployment/production-prepared.json'
UNIT=pathlib.Path('/etc/systemd/system/himawari.service')
AUTH=pathlib.Path('/etc/himawari/runtime.json')
CANDIDATE_AUTH=pathlib.Path('/etc/himawari/fc2b318-candidate.json')
BACKUP_ID='before-fc2b318-2026-09-28'
ATTESTATION=STATE/'deployment/startup-attestation.json'
OLD_START=R/'qualifications/2026-09-28-ddbdac7-installation/hermes-ddbdac7-start.mjs'
OLD_PHYSICAL=pathlib.Path('/opt/himawari/releases/2026-09-28-ddbdac7')
ALLOWED_ACTIVE_RUNS={'run:3e15ce20-48db-4d49-a734-c157052d37dc'}
SCHEMA=49
ACCEPTED_REF='himawari.pi-coding'
ACCEPTED_PATHS={'integrity','artifact.digest'}
EXPECTED_RECEIPT=sys.argv[3] if len(sys.argv)==4 and sys.argv[1:3]==['--apply','--receipt'] else ''
EXPECTED_CURRENT_RUNTIME='38b0e3769130dc703be37e1aaff4cfdaa49057c1b656e6e4ed7083a558f96e7a'
START_SHA='78ffc1ef7dc93b9273239acc73e65eb16726a595c290a45c82f0a37952db37fa'
STATIC_COUNT=26
INPUTS={'hermes-fc2b318-web-probe.mjs':'1c85a403c5ca49a541962f426258d07121432c20e92707663227efb54bfe6ff9'}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def plain(p):
 s=p.lstat();assert not p.is_symlink() and p.resolve()==p,'UNSAFE_PATH';return s
def publish(name,value):
 p=W/name;t=p.with_name(p.name+'.next');t.write_text(json.dumps(value,indent=2)+'\n');t.chmod(0o644);os.replace(t,p)
def status(phase):publish('status.json',{'phase':phase,'at':time.time()});print(phase,flush=True)
def command(args,timeout=90):return subprocess.run(list(map(str,args)),check=True,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
def invoke(phase,args,candidate_view=False,protected=True):
 props=['User=himawari','Group=himawari','NoNewPrivileges=yes','CapabilityBoundingSet=','AmbientCapabilities=','UMask=0077','RuntimeMaxSec=900','WorkingDirectory='+str(R),'TemporaryFileSystem=/data/hermes:ro,mode=0755','BindPaths='+str(R)]
 if candidate_view:props+=['BindReadOnlyPaths='+str(CANDIDATE)+':'+str(CURRENT)+' '+str(CANDIDATE_AUTH)+':'+str(AUTH)]
 else:props+=['BindReadOnlyPaths='+str(OLD_PHYSICAL)+':'+str(CURRENT)]
 cmd=['systemd-run','--quiet','--wait','--pipe','--collect','--unit=himawari-fc2b318-cutover-'+phase]
 for p in props:cmd+=['--property='+p]
 env={'PATH':str(RUNTIME/'pi-tools/bin')+':/usr/bin:/bin','HOME':str(STATE),'LANG':'C.UTF-8'}
 if protected:env['HIMAWARI_RUNTIME_PROTECTION_FILE']=str(AUTH)
 cmd+=['/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*map(str,args)]
 with (W/'private'/(phase+'.stdout')).open('x') as out,(W/'private'/(phase+'.stderr')).open('x') as err:
  result=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=930)
 if result.returncode:
  error=(W/'private'/(phase+'.stderr')).read_text(errors='replace')+(W/'private'/(phase+'.stdout')).read_text(errors='replace')
  publish('failure.json',{'phase':phase,'exitCode':result.returncode,'codes':sorted(set(re.findall(r'\b(?:IMPORT|CUTOVER|SANDBOX|RECOVERY_POINT|ADMIN_CLI|ADMIN|PORT|MIGRATION|DELETION|GOVERNED)_[A-Z0-9_]+\b',error)))})
  raise RuntimeError('CUTOVER_CHILD_FAILED')
 lines=(W/'private'/(phase+'.stdout')).read_text().splitlines()
 values=[json.loads(line) for line in lines if line.strip()]
 assert values,'MISSING_OPERATION_RESULT';return values[-1]
def database_check():
 with sqlite3.connect('file:'+str(STATE/'data/product.sqlite')+'?mode=ro',uri=True) as db:
  assert db.execute('SELECT max(sequence) FROM schema_migration_ledger').fetchone()[0]==SCHEMA,'CUTOVER_SCHEMA_UNEXPECTED'
  active={row[0] for row in db.execute("SELECT id FROM runs WHERE status NOT IN ('completed','failed','cancelled')")}
  assert active<=ALLOWED_ACTIVE_RUNS,'CUTOVER_ACTIVE_RUNS'
  assert db.execute('SELECT count(*) FROM built_in_accounts').fetchone()[0]==0,'CUTOVER_IDENTITY_SCOPE_CHANGED'
  assert not db.execute('PRAGMA foreign_key_check').fetchall(),'CUTOVER_FOREIGN_KEY_FAILURE'
  for (value,) in db.execute('SELECT facts_json FROM sandbox_execution_records'):
   facts=json.loads(value);resource=facts.get('resource',{})
   assert resource.get('cleanup')=='confirmed' and resource.get('supervision')=='released','CUTOVER_SANDBOX_UNRESOLVED'
  for (value,) in db.execute('SELECT observation_json FROM sandbox_jobs'):
   observed=json.loads(value);assert observed.get('state') in ('completed','failed') and observed.get('cleanup')=='confirmed','CUTOVER_LEGACY_SANDBOX_UNRESOLVED'
  return {'schema':SCHEMA,'activeRuns':sorted(active),'runs':db.execute('SELECT count(*) FROM runs').fetchone()[0],'threads':db.execute('SELECT count(*) FROM threads').fetchone()[0],'executionRecords':db.execute('SELECT count(*) FROM sandbox_execution_records').fetchone()[0]}
def differences(a,b,prefix=''):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict):
  return [d for k in sorted(set(a)|set(b)) for d in differences(a.get(k),b.get(k),prefix+('.' if prefix else '')+k)]
 return [(prefix,a,b)]
def normalize(m):return {**m,'health':{**m['health'],'checkedAt':None},'reviewedAt':None}
def registry_deviation(config):
 snapshot=json.loads(pathlib.Path(config['capabilityDeployment']['snapshotPath']).read_text())
 found=[]
 with sqlite3.connect('file:'+str(STATE/'data/product.sqlite')+'?mode=ro',uri=True) as db:
  for entry in snapshot['capabilities']:
   row=db.execute('SELECT record_json FROM capability_declarations WHERE owner_id=? AND agent_id=? AND id=?',(config['ownerId'],config['agentId'],entry['manifest']['ref'])).fetchone()
   assert row,'REGISTERED_CAPABILITY_MISSING'
   record=json.loads(row[0]);assert record['lifecycle']=='active','REGISTERED_CAPABILITY_INACTIVE'
   for path,registered,deployed in differences(normalize(record['declaration']),normalize(entry['manifest'])):
    found.append({'ref':entry['manifest']['ref'],'path':path,'registered':registered,'snapshot':deployed})
 assert all(d['ref']==ACCEPTED_REF and d['path'] in ACCEPTED_PATHS for d in found),'REGISTRY_DIFFERENCE_NOT_ACCEPTED'
 return found
def restore_file(name,destination):
 source=W/'private'/name;info=source.stat();fd,filename=tempfile.mkstemp(prefix='.fc2b318-restore-',dir=destination.parent)
 with os.fdopen(fd,'wb') as out,source.open('rb') as incoming:
  shutil.copyfileobj(incoming,out);out.flush();os.fchown(out.fileno(),info.st_uid,info.st_gid);os.fchmod(out.fileno(),stat.S_IMODE(info.st_mode));os.fsync(out.fileno())
 os.replace(filename,destination)
def private_copy(source,destination,uid=998,gid=998):
 incoming=os.open(source,os.O_RDONLY|os.O_NOFOLLOW)
 assert stat.S_ISREG(os.fstat(incoming).st_mode),'COPY_SOURCE_NOT_REGULAR'
 fd=os.open(destination,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(incoming,'rb') as src,os.fdopen(fd,'wb') as out:
  shutil.copyfileobj(src,out);out.flush();os.fchown(out.fileno(),uid,gid);os.fsync(out.fileno())
def main():
 assert os.geteuid()==0 and sys.flags.optimize==0 and len(sys.argv)==4 and sys.argv[1:3]==['--apply','--receipt']
 assert socket.gethostname()=='hermes-home' and os.environ.get('INVOCATION_ID')
 assert command(['findmnt','-no','TARGET','--target',R]).stdout.strip()=='/data'
 assert shutil.disk_usage(R).free>10*1024**3
 assert not W.exists(),'CUTOVER_ALREADY_ATTEMPTED'
 assert not PREPARED.exists(),'STALE_PREPARED_CONFIG'
 assert re.fullmatch('[0-9a-f]{64}',EXPECTED_RECEIPT),'QUALIFICATION_NOT_BOUND'
 assert command(['systemctl','is-active','himawari.service']).stdout.strip()=='active'
 assert command(['systemctl','show','himawari.service','-p','User','--value']).stdout.strip()=='himawari'
 qualified=json.loads((Q/'result.json').read_text());assert qualified['passed'] and json.loads((Q/'status.json').read_text())['passed'] is True
 assert sha(Q/'installation-receipt.json')==qualified['receiptDigest']==EXPECTED_RECEIPT
 assert json.loads(CANDIDATE_AUTH.read_text())['runtimeDigest']==qualified['runtimeDigest']
 assert plain(CANDIDATE).st_uid==0 and plain(CANDIDATE_AUTH).st_uid==0 and plain(AUTH).st_uid==0
 assert json.loads(AUTH.read_text())['runtimeDigest']==EXPECTED_CURRENT_RUNTIME,'CURRENT_INSTALLATION_CHANGED'
 for name,digest in INPUTS.items():assert sha(HERE/name)==digest,'REVIEWED_HELPER_CHANGED'
 assert sha(Q/'hermes-fc2b318-start.mjs')==START_SHA
 original_unit=UNIT.read_text();node=RUNTIME/'pi-tools/bin/node'
 old_exec='ExecStart='+str(node)+' '+str(OLD_START)
 old_mount='BindReadOnlyPaths='+str(OLD_PHYSICAL)+':'+str(CURRENT)
 assert original_unit.count(old_exec)==1,'UNEXPECTED_SERVICE_UNIT'
 assert original_unit.count(old_mount)==1,'UNEXPECTED_EXISTING_RUNTIME_MOUNT'
 assert CANDIDATE.stat().st_dev!=CURRENT.stat().st_dev,'RUNTIME_NOT_ON_ANOTHER_DEVICE'
 database_check()
 os.umask(0o077);W.mkdir(mode=0o711);W.chmod(0o711);(W/'private').mkdir(mode=0o700)
 for name,digest in INPUTS.items():
  shutil.copyfile(HERE/name,W/name);(W/name).chmod(0o644);assert sha(W/name)==digest,'COPIED_HELPER_CHANGED'
 for source,name in [(CONFIG,'production-before.json'),(UNIT,'unit-before.service'),(AUTH,'authority-before.json'),(ATTESTATION,'attestation-before.json')]:
  target=W/'private'/name;shutil.copy2(source,target);os.chown(target,source.stat().st_uid,source.stat().st_gid)
 stopped=False;switched=False;new_started=False
 common=['--config',CONFIG,'--secret-dir',STATE/'secrets']
 try:
  status('checking_candidate_browser_before_stopping_service')
  assert json.loads(CONFIG.read_text())['http']['staticRoot']==str(CURRENT/'share/control-center'),'STATIC_ROOT_CONFIGURATION_CHANGED'
  web=invoke('web-static',[node,W/'hermes-fc2b318-web-probe.mjs'],True)
  assert web['passed'] and web['runtimeUid']==998 and web['staticFiles']==STATIC_COUNT
  publish('web-static-preflight.json',web)
  status('stopping_service_for_verified_backup');stopped=True;command(['systemctl','stop','himawari.service'],90)
  assert command(['systemctl','show','himawari.service','-p','MainPID','--value']).stdout.strip()=='0'
  publish('database-before.json',database_check())
  for action,option in [('create','--backup-id'),('verify','--backup')]:
   result=invoke('backup-'+action,[CURRENT/'bin/himawari','backup',action,*common,option,BACKUP_ID])
   assert result['backupId']==BACKUP_ID and result['schemaVersion']==str(SCHEMA) and result['fullIntegrityCheck']=='ok';publish('backup-'+action+'.json',result)
  deadline=time.time()+125
  while True:
   with sqlite3.connect('file:'+str(STATE/'data/product.sqlite')+'?mode=ro',uri=True) as db:
    active=db.execute("SELECT count(*) FROM authority_leases WHERE expires_at > strftime('%Y-%m-%dT%H:%M:%fZ','now')").fetchone()[0]
   if not active:break
   assert time.time()<deadline,'CUTOVER_AUTHORITY_NOT_RELEASED';time.sleep(1)
  status('preparing_qualified_startup')
  private_copy(CONFIG,PREPARED)
  startup=invoke('prepare',[node,Q/'hermes-fc2b318-start.mjs','--prepare',PREPARED],True);assert startup['preparing'];assert startup['runtimeDigest']==qualified['runtimeDigest']
  config=json.loads(PREPARED.read_text())
  publish('registry-deviation.json',{'ownerDecision':'start_now_update_registry_later','decidedAt':'2026-09-27','differences':registry_deviation(config),'registryWritten':False})
  publish('database-before-switch.json',database_check())
  status('switching_verified_installation');switched=True
  authority_next=AUTH.with_name('runtime.fc2b318-next.json');shutil.copyfile(CANDIDATE_AUTH,authority_next);authority_next.chmod(0o644);os.replace(authority_next,AUTH)
  os.replace(PREPARED,CONFIG)
  next_unit=UNIT.with_name('himawari.service.fc2b318-next');next_unit.write_text(original_unit.replace(old_exec,'ExecStart='+str(node)+' '+str(Q/'hermes-fc2b318-start.mjs')).replace(old_mount,'BindReadOnlyPaths='+str(CANDIDATE)+':'+str(CURRENT)));next_unit.chmod(0o644);os.replace(next_unit,UNIT)
  command(['systemd-analyze','verify',UNIT]);command(['systemctl','daemon-reload'])
  offsets={name:(R/'logs'/f'{name}.log').stat().st_size for name in ['agent','worker']}
  status('starting_qualified_release');new_started=True;command(['systemctl','start','himawari.service'],120)
  ready=set();deadline=time.time()+300
  while time.time()<deadline:
   for name,offset in offsets.items():
    with (R/'logs'/f'{name}.log').open('rb') as f:f.seek(offset);data=f.read(4*1024*1024)
    if b'"event":"service.ready"' in data or b'"event": "service.ready"' in data:ready.add(name)
   if len(ready)==2:break
   time.sleep(1)
  assert ready=={'agent','worker'},'CUTOVER_SERVICE_NOT_READY'
  assert command(['systemctl','is-active','himawari.service']).stdout.strip()=='active'
  pid=command(['systemctl','show','himawari.service','-p','MainPID','--value']).stdout.strip()
  live=(pathlib.Path('/proc')/pid/'status').read_text()
  assert re.search(r'^Uid:\s+998\s+998\s+998\s+998$',live,re.M) and re.search(r'^NoNewPrivs:\s+1$',live,re.M)
  publish('result.json',{'passed':True,'deploymentComplete':True,'schemaSequence':SCHEMA,'migrated':False,'deletedRecords':0,'runtimeDigest':qualified['runtimeDigest'],'receiptDigest':EXPECTED_RECEIPT,'ready':sorted(ready),'runtimeUid':998,'mainPid':int(pid),'backupId':BACKUP_ID,'allowedActiveRuns':sorted(ALLOWED_ACTIVE_RUNS),'modelCalls':0,'realModelAcceptance':'not_run_no_model_calls','sourceCommit':'fc2b318364ea7445841a53a133c9ff1b9de4bbe9','physicalPrefix':str(CANDIDATE),'capabilityDeclarationsUnchanged':False,'registryDeviation':'registry-deviation.json'})
  status('deployment_completed_public_browser_verification_pending')
 except BaseException as error:
  rollback={'attempted':False,'completed':False,'switched':switched,'newServiceStartAttempted':new_started}
  try:
   if stopped:
    rollback['attempted']=True
    if new_started:command(['systemctl','stop','himawari.service'],90)
    if PREPARED.exists():PREPARED.unlink()
    restore_file('attestation-before.json',ATTESTATION)
    restore_file('production-before.json',CONFIG);restore_file('unit-before.service',UNIT);restore_file('authority-before.json',AUTH)
    command(['systemctl','daemon-reload'])
    command(['systemctl','start','himawari.service'],120)
    rollback['originalServiceStarted']=True;rollback['completed']=True
  except BaseException as recovery_error:rollback['errorType']=type(recovery_error).__name__
  publish('exception.json',{'exceptionType':type(error).__name__,'messageCode':str(error) if re.fullmatch('[A-Z_]+',str(error)) else None,'rollback':rollback})
  status('cutover_failed_review_preserved_evidence');raise

if __name__=='__main__':
 assert os.geteuid()==0 and sys.flags.optimize==0
 assert re.fullmatch('[0-9a-f]{64}',EXPECTED_RECEIPT),'QUALIFICATION_RECEIPT_REQUIRED'
 fd=os.open('/run/himawari-fc2b318-cutover.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
 assert os.fstat(fd).st_uid==0 and stat.S_ISREG(os.fstat(fd).st_mode)
 fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 main()
