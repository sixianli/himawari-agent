#!/usr/bin/python3
"""Schema 32 to 48 cutover for c71adbd: verified backup, migration, owner-approved deletions, installation switch."""
import fcntl,hashlib,json,os,pathlib,re,shutil,socket,sqlite3,stat,subprocess,sys,tempfile,time
R=pathlib.Path('/data/hermes/himawari')
B=R/'builds/2026-09-27-c71adbd'
Q=R/'qualifications/2026-09-27-c71adbd-installation'
W=R/'qualifications/2026-09-27-c71adbd-cutover'
CURRENT=R/'releases/2026-09-11-control-center'
CANDIDATE=pathlib.Path('/opt/himawari/releases/2026-09-27-c71adbd')
RUNTIME=CURRENT/'lib/himawari-agent'
CONFIG=R/'config/production.json'
STATE=R/'state'
UNIT=pathlib.Path('/etc/systemd/system/himawari.service')
AUTH=pathlib.Path('/etc/himawari/runtime.json')
CANDIDATE_AUTH=pathlib.Path('/etc/himawari/c71adbd-candidate.json')
BACKUP_ID='before-c71adbd-2026-09-27'
ATTESTATION=STATE/'deployment/startup-attestation.json'
OLD_START=R/'qualifications/2026-09-16-v4-0600b29-installation/hermes-v4-0600b29-start.mjs'
OLD_PHYSICAL=pathlib.Path('/opt/himawari/releases/2026-09-16-v4-0600b29')
STUCK_RUN='run:2058c816-b008-402f-8b0f-965782d3d03c'
TARGET_SEQUENCE=48
EXPECTED_RECEIPT=sys.argv[3] if len(sys.argv)==4 and sys.argv[1:3]==['--apply','--receipt'] else ''
EXPECTED_CURRENT_RUNTIME='fa74f6a8e5fd245027887dc6b9fc92227a90bf1d7e3b817fe4e01591a82ca005'
START_SHA='5628d9c5c51d3e8c72d819dc91c03d295f7b2515905d647dd53a120fbd86c0b4'
STATIC_COUNT=23
INPUTS={'hermes-protected-registered.mjs': '7904085d39a50e3d2bbab9547ed2e230cc96a9d2592556d8bb5db722b8f6aaa8', 'hermes-c71adbd-web-probe.mjs': '60b3179538cb8470861ab07c1454a78876d169a4f83910805b936c642e271c16'}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def plain(p):
 s=p.lstat();assert not p.is_symlink() and p.resolve()==p,'UNSAFE_PATH';return s
def publish(name,value):
 p=W/name;t=p.with_name(p.name+'.next');t.write_text(json.dumps(value,indent=2)+'\n');t.chmod(0o644);os.replace(t,p)
def status(phase):publish('status.json',{'phase':phase,'at':time.time()});print(phase,flush=True)
def command(args,timeout=90):return subprocess.run(list(map(str,args)),check=True,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
def invoke(phase,args,candidate_view=False,protected=True):
 props=['User=himawari','Group=himawari','NoNewPrivileges=yes','CapabilityBoundingSet=','AmbientCapabilities=','UMask=0077','RuntimeMaxSec=900','WorkingDirectory='+str(R),'TemporaryFileSystem=/data/hermes:ro,mode=0755','BindPaths='+str(R)]
 if candidate_view:props+=['BindReadOnlyPaths='+str(CANDIDATE)+':'+str(CURRENT)+' '+str(CANDIDATE_AUTH)+':'+str(AUTH)]
 else:props+=['BindReadOnlyPaths='+str(OLD_PHYSICAL)+':'+str(CURRENT)]
 cmd=['systemd-run','--quiet','--wait','--pipe','--collect','--unit=himawari-c71adbd-cutover-'+phase]
 for p in props:cmd+=['--property='+p]
 env={'PATH':str(RUNTIME/'pi-tools/bin')+':/usr/bin:/bin','HOME':str(STATE),'LANG':'C.UTF-8'}
 if protected:env['HIMAWARI_RUNTIME_PROTECTION_FILE']=str(AUTH)
 cmd+=['/usr/bin/env','-i',*[k+'='+v for k,v in env.items()],*map(str,args)]
 with (W/'private'/(phase+'.stdout')).open('x') as out,(W/'private'/(phase+'.stderr')).open('x') as err:
  result=subprocess.run(cmd,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=930)
 if result.returncode:
  error=(W/'private'/(phase+'.stderr')).read_text(errors='replace')+(W/'private'/(phase+'.stdout')).read_text(errors='replace')
  publish('failure.json',{'phase':phase,'exitCode':result.returncode,'codes':sorted(set(re.findall(r'\b(?:IMPORT|CUTOVER|SANDBOX|RECOVERY_POINT|ADMIN_CLI|ADMIN|PORT|MIGRATION|DELETION|GOVERNED)_[A-Z0-9_]+\b',error)))})
  raise RuntimeError('CUTOVER_CHILD_FAILED')
 lines=(W/'private'/(phase+'.stdout')).read_text().splitlines()
 values=[json.loads(line) for line in lines if line.strip()]
 assert values,'MISSING_OPERATION_RESULT';return values[-1]
def database_check(sequence,allowed_active):
 with sqlite3.connect('file:'+str(STATE/'data/product.sqlite')+'?mode=ro',uri=True) as db:
  assert db.execute('SELECT max(sequence) FROM schema_migration_ledger').fetchone()[0]==sequence,'CUTOVER_SCHEMA_UNEXPECTED'
  active={row[0] for row in db.execute("SELECT id FROM runs WHERE status NOT IN ('completed','failed','cancelled')")}
  assert active==set(allowed_active),'CUTOVER_ACTIVE_RUNS'
  assert db.execute('SELECT count(*) FROM built_in_accounts').fetchone()[0]==0,'CUTOVER_IDENTITY_SCOPE_CHANGED'
  assert not db.execute('PRAGMA foreign_key_check').fetchall(),'CUTOVER_FOREIGN_KEY_FAILURE'
  for (value,) in db.execute('SELECT facts_json FROM sandbox_execution_records'):
   facts=json.loads(value);resource=facts.get('resource',{})
   assert resource.get('cleanup')=='confirmed' and resource.get('supervision')=='released','CUTOVER_SANDBOX_UNRESOLVED'
  for (value,) in db.execute('SELECT observation_json FROM sandbox_jobs'):
   observed=json.loads(value);assert observed.get('state') in ('completed','failed') and observed.get('cleanup')=='confirmed','CUTOVER_LEGACY_SANDBOX_UNRESOLVED'
  return {'schema':sequence,'activeRuns':sorted(active),'runs':db.execute('SELECT count(*) FROM runs').fetchone()[0],'threads':db.execute('SELECT count(*) FROM threads').fetchone()[0],'executionRecords':db.execute('SELECT count(*) FROM sandbox_execution_records').fetchone()[0]}
def restore_file(name,destination):
 source=W/'private'/name;info=source.stat();fd,filename=tempfile.mkstemp(prefix='.c71adbd-restore-',dir=destination.parent)
 with os.fdopen(fd,'wb') as out,source.open('rb') as incoming:
  shutil.copyfileobj(incoming,out);out.flush();os.fchown(out.fileno(),info.st_uid,info.st_gid);os.fchmod(out.fileno(),stat.S_IMODE(info.st_mode));os.fsync(out.fileno())
 os.replace(filename,destination)
def private_copy(source,destination,uid=998,gid=998):
 incoming=os.open(source,os.O_RDONLY|os.O_NOFOLLOW)
 assert stat.S_ISREG(os.fstat(incoming).st_mode),'COPY_SOURCE_NOT_REGULAR'
 fd=os.open(destination,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(incoming,'rb') as src,os.fdopen(fd,'wb') as out:
  shutil.copyfileobj(src,out);out.flush();os.fchown(out.fileno(),uid,gid);os.fsync(out.fileno())
def main():
 assert os.geteuid()==0 and sys.flags.optimize==0 and len(sys.argv)==4 and sys.argv[1:3]==['--apply','--receipt']
 assert socket.gethostname()=='hermes-home' and os.environ.get('INVOCATION_ID')
 assert command(['findmnt','-no','TARGET','--target',R]).stdout.strip()=='/data'
 assert shutil.disk_usage(R).free>10*1024**3
 assert not W.exists(),'CUTOVER_ALREADY_ATTEMPTED'
 assert not (STATE/'deployment/production-prepared.json').exists(),'STALE_PREPARED_CONFIG'
 assert re.fullmatch('[0-9a-f]{64}',EXPECTED_RECEIPT),'QUALIFICATION_NOT_BOUND'
 assert command(['systemctl','is-active','himawari.service']).stdout.strip()=='active'
 assert command(['systemctl','show','himawari.service','-p','User','--value']).stdout.strip()=='himawari'
 qualified=json.loads((Q/'result.json').read_text());assert qualified['passed'] and json.loads((Q/'status.json').read_text())['passed'] is True
 assert sha(Q/'installation-receipt.json')==qualified['receiptDigest']==EXPECTED_RECEIPT
 assert json.loads(CANDIDATE_AUTH.read_text())['runtimeDigest']==qualified['runtimeDigest']
 assert plain(CANDIDATE).st_uid==0 and plain(CANDIDATE_AUTH).st_uid==0 and plain(AUTH).st_uid==0
 assert json.loads(AUTH.read_text())['runtimeDigest']==EXPECTED_CURRENT_RUNTIME,'CURRENT_INSTALLATION_CHANGED'
 for name,digest in INPUTS.items():assert sha(B/name)==digest,'REVIEWED_HELPER_CHANGED'
 assert sha(Q/'hermes-c71adbd-start.mjs')==START_SHA
 original_unit=UNIT.read_text();old_exec='ExecStart='+str(RUNTIME/'pi-tools/bin/node')+' '+str(OLD_START)
 old_mount='BindReadOnlyPaths='+str(OLD_PHYSICAL)+':'+str(CURRENT)
 assert original_unit.count(old_exec)==1,'UNEXPECTED_SERVICE_UNIT'
 assert original_unit.count(old_mount)==1,'UNEXPECTED_EXISTING_RUNTIME_MOUNT'
 assert CANDIDATE.stat().st_dev!=CURRENT.stat().st_dev,'RUNTIME_NOT_ON_ANOTHER_DEVICE'
 database_check(32,{STUCK_RUN})
 os.umask(0o077);W.mkdir(mode=0o711);W.chmod(0o711);(W/'private').mkdir(mode=0o700)
 for name,digest in INPUTS.items():
  shutil.copyfile(B/name,W/name);(W/name).chmod(0o644);assert sha(W/name)==digest,'COPIED_HELPER_CHANGED'
 for source,name in [(CONFIG,'production-before.json'),(UNIT,'unit-before.service'),(AUTH,'authority-before.json'),(ATTESTATION,'attestation-before.json')]:
  target=W/'private'/name;shutil.copy2(source,target);os.chown(target,source.stat().st_uid,source.stat().st_gid)
 stopped=False;migrating=False;new_started=False
 node=RUNTIME/'pi-tools/bin/node'
 common=['--config',CONFIG,'--secret-dir',STATE/'secrets']
 try:
  status('checking_candidate_browser_before_stopping_service')
  assert json.loads(CONFIG.read_text())['http']['staticRoot']==str(CURRENT/'share/control-center'),'STATIC_ROOT_CONFIGURATION_CHANGED'
  web=invoke('web-static',[node,W/'hermes-c71adbd-web-probe.mjs'],True)
  assert web['passed'] and web['runtimeUid']==998 and web['staticFiles']==STATIC_COUNT
  publish('web-static-preflight.json',web)
  status('stopping_idle_service_for_verified_backup');stopped=True;command(['systemctl','stop','himawari.service'],90)
  assert command(['systemctl','show','himawari.service','-p','MainPID','--value']).stdout.strip()=='0'
  publish('database-before.json',database_check(32,{STUCK_RUN}))
  for action,option in [('create','--backup-id'),('verify','--backup')]:
   result=invoke('backup-'+action,[CURRENT/'bin/himawari','backup',action,*common,option,BACKUP_ID])
   assert result['backupId']==BACKUP_ID and result['schemaVersion']=='32' and result['fullIntegrityCheck']=='ok';publish('backup-'+action+'.json',result)
  deadline=time.time()+125
  while True:
   with sqlite3.connect('file:'+str(STATE/'data/product.sqlite')+'?mode=ro',uri=True) as db:
    active=db.execute("SELECT count(*) FROM authority_leases WHERE expires_at > strftime('%Y-%m-%dT%H:%M:%fZ','now')").fetchone()[0]
   if not active:break
   assert time.time()<deadline,'CUTOVER_AUTHORITY_NOT_RELEASED';time.sleep(1)
  status('migrating_schema_32_to_48_after_verified_backup');migrating=True
  migrated=invoke('migrate',[CURRENT/'bin/himawari','db','migrate','--config',CONFIG,'--confirm','APPLY_MIGRATIONS'],True)
  assert migrated['currentSequence']==TARGET_SEQUENCE and migrated['appliedSequences']==list(range(33,TARGET_SEQUENCE+1)) and migrated['snapshotPath'],'CUTOVER_MIGRATION_UNEXPECTED'
  publish('migrate.json',migrated)
  database_check(TARGET_SEQUENCE,{STUCK_RUN})
  status('deleting_owner_approved_stuck_run')
  inspected=invoke('delete-inspect',[CURRENT/'bin/himawari','delete','inspect','--config',CONFIG,'--type','run','--id',STUCK_RUN],True)
  publish('delete-inspect.json',inspected)
  deleted=invoke('delete-purge',[CURRENT/'bin/himawari','delete','purge','--config',CONFIG,'--type','run','--id',STUCK_RUN,'--confirm','DELETE_run_'+STUCK_RUN],True)
  publish('delete-purge.json',deleted)
  publish('database-after-run-deletion.json',database_check(TARGET_SEQUENCE,set()))
  status('listing_unconfirmed_srt_records')
  listing=invoke('purge-list',[CURRENT/'bin/himawari','sandbox','list-unconfirmed','--config',CONFIG],True)
  publish('unconfirmed-before.json',listing)
  if listing['records']:
   purged=invoke('purge-apply',[CURRENT/'bin/himawari','sandbox','purge-unconfirmed','--config',CONFIG,'--digest',listing['digest']],True)
   publish('unconfirmed-purge.json',purged)
   after=invoke('purge-list-after',[CURRENT/'bin/himawari','sandbox','list-unconfirmed','--config',CONFIG],True)
   assert not after['records'],'CUTOVER_PURGE_INCOMPLETE';publish('unconfirmed-after.json',after)
  status('preparing_qualified_startup_after_migration')
  prepared=STATE/'deployment/production-prepared.json';private_copy(CONFIG,prepared)
  startup=invoke('prepare',[node,Q/'hermes-c71adbd-start.mjs','--prepare',prepared],True);assert startup['preparing'];assert startup['runtimeDigest']==qualified['runtimeDigest']
  registry=invoke('registered',[node,W/'hermes-protected-registered.mjs'],True);assert registry['registeredCapabilitiesUnchanged'];publish('registered-preflight.json',registry)
  publish('database-before-switch.json',database_check(TARGET_SEQUENCE,set()))
  status('switching_verified_installation')
  authority_next=AUTH.with_name('runtime.c71adbd-next.json');shutil.copyfile(CANDIDATE_AUTH,authority_next);authority_next.chmod(0o644);os.replace(authority_next,AUTH)
  os.replace(prepared,CONFIG)
  next_unit=UNIT.with_name('himawari.service.c71adbd-next');next_unit.write_text(original_unit.replace(old_exec,'ExecStart='+str(node)+' '+str(Q/'hermes-c71adbd-start.mjs')).replace(old_mount,'BindReadOnlyPaths='+str(CANDIDATE)+':'+str(CURRENT)));next_unit.chmod(0o644);os.replace(next_unit,UNIT)
  command(['systemd-analyze','verify',UNIT]);command(['systemctl','daemon-reload'])
  offsets={name:(R/'logs'/f'{name}.log').stat().st_size for name in ['agent','worker']}
  status('starting_qualified_release');new_started=True;command(['systemctl','start','himawari.service'])
  ready=set();deadline=time.time()+300
  while time.time()<deadline:
   for name,offset in offsets.items():
    with (R/'logs'/f'{name}.log').open('rb') as f:f.seek(offset);data=f.read(4*1024*1024)
    if b'"event":"service.ready"' in data or b'"event": "service.ready"' in data:ready.add(name)
   if len(ready)==2:break
   time.sleep(1)
  assert ready=={'agent','worker'},'CUTOVER_SERVICE_NOT_READY'
  assert command(['systemctl','is-active','himawari.service']).stdout.strip()=='active'
  pid=command(['systemctl','show','himawari.service','-p','MainPID','--value']).stdout.strip();process_status=pathlib.Path('/proc')/pid/'status'
  live_process=process_status.read_text();assert re.search(r'^Uid:\s+998\s+998\s+998\s+998$',live_process,re.M) and re.search(r'^NoNewPrivs:\s+1$',live_process,re.M)
  publish('result.json',{'passed':True,'deploymentComplete':True,'schemaSequence':TARGET_SEQUENCE,'migratedFrom':32,'historyReimported':False,'runtimeDigest':qualified['runtimeDigest'],'receiptDigest':EXPECTED_RECEIPT,'ready':sorted(ready),'runtimeUid':998,'backupId':BACKUP_ID,'deletedRun':STUCK_RUN,'unconfirmedRecordsPurged':len(listing['records']),'modelCalls':0,'realModelAcceptance':'not_run_no_model_calls','sourceCommit':'c71adbd5f23a88834512ad26112f587d6fa993b9','startupVerification':True,'physicalPrefix':str(CANDIDATE),'capabilityDeclarationsUnchanged':True})
  status('deployment_completed_public_browser_verification_pending')
 except BaseException as error:
  rollback={'attempted':False,'completed':False,'migrationStarted':migrating,'newServiceStartAttempted':new_started}
  try:
   if new_started:
    command(['systemctl','stop','himawari.service'],90)
    rollback['reason']='preserve_post_start_data_for_diagnosis'
   elif migrating:
    rollback['reason']='database_migration_started_restore_verified_backup_manually'
   elif stopped:
    rollback['attempted']=True
    restore_file('attestation-before.json',ATTESTATION)
    restore_file('production-before.json',CONFIG);restore_file('unit-before.service',UNIT);restore_file('authority-before.json',AUTH)
    command(['systemctl','daemon-reload'])
    command(['systemctl','start','himawari.service'])
    rollback['originalServiceStarted']=True;rollback['completed']=True
  except BaseException as recovery_error:rollback['errorType']=type(recovery_error).__name__
  publish('exception.json',{'exceptionType':type(error).__name__,'messageCode':str(error) if re.fullmatch('[A-Z_]+',str(error)) else None,'rollback':rollback})
  status('cutover_failed_review_preserved_evidence');raise

if __name__=='__main__':
 assert os.geteuid()==0 and sys.flags.optimize==0
 assert re.fullmatch('[0-9a-f]{64}',EXPECTED_RECEIPT),'QUALIFICATION_RECEIPT_REQUIRED'
 fd=os.open('/run/himawari-three-fixes-cutover.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
 assert os.fstat(fd).st_uid==0 and stat.S_ISREG(os.fstat(fd).st_mode)
 fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 main()
