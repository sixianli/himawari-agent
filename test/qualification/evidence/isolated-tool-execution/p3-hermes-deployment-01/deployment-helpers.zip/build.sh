#!/bin/bash
set -euo pipefail
umask 077
B=/data/hermes/himawari/builds/2026-09-27-c71adbd
TOOLS=/data/hermes/himawari/builds/2026-09-14-ci-complete-repair/source/.ci-output/security-tools
OLD_RELEASE=/opt/himawari/releases/2026-09-16-v4-0600b29
export PATH="$TOOLS/bin:/usr/bin:/bin"
export TMPDIR="$B/tmp"
export HIMAWARI_CI_PYTHON="$TOOLS/python/python/bin/python3"
cd "$B"
test "$(sha256sum source.tar.gz | cut -d' ' -f1)" = "$(python3 -c 'import json;print(json.load(open("source-manifest.json"))["archiveSha256"])')"
mkdir source tmp
tar -xzf source.tar.gz -C source
python3 - <<'PY'
import hashlib, json, pathlib
B = pathlib.Path("/data/hermes/himawari/builds/2026-09-27-c71adbd")
m = json.loads((B / "source-manifest.json").read_text())
for e in m["files"]:
    assert hashlib.sha256((B / "source" / e["path"]).read_bytes()).hexdigest() == e["sha256"], e["path"]
print("source verified", len(m["files"]))
PY
mkdir -p source/.ci-output/npm-cache
for cache in /data/hermes/himawari/builds/*/source/.ci-output/npm-cache /data/hermes/himawari/builds/*/.ci-output/npm-cache /data/hermes/himawari/builds/*/*/.ci-output/npm-cache /data/hermes/himawari/builds/*/*/*/.ci-output/npm-cache; do
  case "$cache" in "$B"/*) continue;; esac
  for part in _cacache/content-v2 _cacache/index-v5; do
    if [ -d "$cache/$part" ]; then mkdir -p "source/.ci-output/npm-cache/$part"; cp -an "$cache/$part/." "source/.ci-output/npm-cache/$part/"; fi
  done
done
cd source
printf 'prefer-offline=true\n' > .npmrc
node scripts/ci/install-dependencies.mjs --tools "$TOOLS" --evidence .ci-output/installation --cache .ci-output/npm-cache > "$B/dependencies.log" 2>&1
node "$TOOLS/npm/package/bin/npm-cli.js" run build > "$B/build.log" 2>&1
node scripts/install-node-runtime.mjs --prefix "$B/prefix" > "$B/install.log" 2>&1
cp -a "$OLD_RELEASE/lib/himawari-agent/pi-tools" "$B/prefix/lib/himawari-agent/pi-tools"
mkdir -p "$B/prefix/share"
cp -a apps/control-center/dist "$B/prefix/share/control-center"
python3 "$B/finalize.py"
