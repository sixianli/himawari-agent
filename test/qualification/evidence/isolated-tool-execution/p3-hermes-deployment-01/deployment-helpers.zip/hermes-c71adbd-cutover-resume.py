#!/usr/bin/python3
"""Resume the c71adbd cutover after the registered-capability gate stopped it; the owner accepted the pi-coding integrity-only difference on 2026-09-27."""
import json,os,pathlib,re,sqlite3,subprocess,sys,time
R=pathlib.Path('/data/hermes/himawari')
Q=R/'qualifications/2026-09-27-c71adbd-installation'
W=R/'qualifications/2026-09-27-c71adbd-cutover'
CURRENT=R/'releases/2026-09-11-control-center'
CANDIDATE=pathlib.Path('/opt/himawari/releases/2026-09-27-c71adbd')
RUNTIME=CURRENT/'lib/himawari-agent'
CONFIG=R/'config/production.json'
STATE=R/'state'
PREPARED=STATE/'deployment/production-prepared.json'
UNIT=pathlib.Path('/etc/systemd/system/himawari.service')
AUTH=pathlib.Path('/etc/himawari/runtime.json')
CANDIDATE_AUTH=pathlib.Path('/etc/himawari/c71adbd-candidate.json')
OLD_START=R/'qualifications/2026-09-16-v4-0600b29-installation/hermes-v4-0600b29-start.mjs'
OLD_PHYSICAL=pathlib.Path('/opt/himawari/releases/2026-09-16-v4-0600b29')
ACCEPTED_REF='himawari.pi-coding'
ACCEPTED_PATHS={'integrity','artifact.digest'}

def publish(name,value):
 p=W/name;t=p.with_name(p.name+'.next');t.write_text(json.dumps(value,indent=2)+'\n');t.chmod(0o644);os.replace(t,p)
def status(phase):publish('status.json',{'phase':phase,'at':time.time()});print(phase,flush=True)
def command(args,timeout=90):return subprocess.run(list(map(str,args)),check=True,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=timeout)
def differences(a,b,prefix=''):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict):
  return [d for k in sorted(set(a)|set(b)) for d in differences(a.get(k),b.get(k),prefix+('.' if prefix else '')+k)]
 return [(prefix,a,b)]
def normalize(m):return {**m,'health':{**m['health'],'checkedAt':None},'reviewedAt':None}
def registry_deviation(config):
 snapshot=json.loads(pathlib.Path(config['capabilityDeployment']['snapshotPath']).read_text())
 found=[]
 with sqlite3.connect('file:'+str(STATE/'data/product.sqlite')+'?mode=ro',uri=True) as db:
  for entry in snapshot['capabilities']:
   row=db.execute('SELECT record_json FROM capability_declarations WHERE owner_id=? AND agent_id=? AND id=?',(config['ownerId'],config['agentId'],entry['manifest']['ref'])).fetchone()
   assert row,'REGISTERED_CAPABILITY_MISSING'
   record=json.loads(row[0]);assert record['lifecycle']=='active','REGISTERED_CAPABILITY_INACTIVE'
   for path,registered,deployed in differences(normalize(record['declaration']),normalize(entry['manifest'])):
    found.append({'ref':entry['manifest']['ref'],'path':path,'registered':registered,'snapshot':deployed})
 assert found and all(d['ref']==ACCEPTED_REF and d['path'] in ACCEPTED_PATHS for d in found),'REGISTRY_DIFFERENCE_NOT_ACCEPTED'
 return found
def database_check():
 with sqlite3.connect('file:'+str(STATE/'data/product.sqlite')+'?mode=ro',uri=True) as db:
  assert db.execute('SELECT max(sequence) FROM schema_migration_ledger').fetchone()[0]==48,'CUTOVER_SCHEMA_UNEXPECTED'
  active=[r[0] for r in db.execute("SELECT id FROM runs WHERE status NOT IN ('completed','failed','cancelled')")]
  assert not active,'CUTOVER_ACTIVE_RUNS'
  assert not db.execute('PRAGMA foreign_key_check').fetchall(),'CUTOVER_FOREIGN_KEY_FAILURE'
  return {'schema':48,'activeRuns':active,'runs':db.execute('SELECT count(*) FROM runs').fetchone()[0],'threads':db.execute('SELECT count(*) FROM threads').fetchone()[0]}
def main():
 assert os.geteuid()==0 and sys.argv[1:]==['--resume-after-owner-accepted-registry-difference']
 assert os.environ.get('INVOCATION_ID')
 assert json.loads((W/'failure.json').read_text())['phase']=='registered','UNEXPECTED_FAILED_PHASE'
 assert not (W/'result.json').exists() and not (W/'resume.json').exists(),'CUTOVER_ALREADY_RESUMED'
 active=subprocess.run(['systemctl','is-active','himawari.service'],stdout=subprocess.PIPE,text=True).stdout.strip()
 assert active=='inactive','SERVICE_NOT_STOPPED'
 assert AUTH.read_bytes()==(W/'private/authority-before.json').read_bytes(),'AUTHORITY_ALREADY_CHANGED'
 assert CONFIG.read_bytes()==(W/'private/production-before.json').read_bytes(),'CONFIG_ALREADY_CHANGED'
 original_unit=UNIT.read_text();assert original_unit==(W/'private/unit-before.service').read_text(),'UNIT_ALREADY_CHANGED'
 qualified=json.loads((Q/'result.json').read_text());assert qualified['passed']
 assert json.loads(CANDIDATE_AUTH.read_text())['runtimeDigest']==qualified['runtimeDigest']
 node=RUNTIME/'pi-tools/bin/node'
 old_exec='ExecStart='+str(node)+' '+str(OLD_START);old_mount='BindReadOnlyPaths='+str(OLD_PHYSICAL)+':'+str(CURRENT)
 assert original_unit.count(old_exec)==1 and original_unit.count(old_mount)==1,'UNEXPECTED_SERVICE_UNIT'
 config=json.loads(PREPARED.read_text())
 deviation=registry_deviation(config)
 publish('registry-deviation.json',{'ownerDecision':'start_now_update_registry_later','decidedAt':'2026-09-27','differences':deviation,'registryWritten':False})
 publish('database-before-switch.json',database_check())
 new_started=False
 try:
  status('switching_verified_installation')
  authority_next=AUTH.with_name('runtime.c71adbd-next.json');authority_next.write_bytes(CANDIDATE_AUTH.read_bytes());authority_next.chmod(0o644);os.replace(authority_next,AUTH)
  os.replace(PREPARED,CONFIG)
  next_unit=UNIT.with_name('himawari.service.c71adbd-next');next_unit.write_text(original_unit.replace(old_exec,'ExecStart='+str(node)+' '+str(Q/'hermes-c71adbd-start.mjs')).replace(old_mount,'BindReadOnlyPaths='+str(CANDIDATE)+':'+str(CURRENT)));next_unit.chmod(0o644);os.replace(next_unit,UNIT)
  command(['systemd-analyze','verify',UNIT]);command(['systemctl','daemon-reload'])
  offsets={name:(R/'logs'/f'{name}.log').stat().st_size for name in ['agent','worker']}
  status('starting_qualified_release');new_started=True;command(['systemctl','start','himawari.service'],120)
  ready=set();deadline=time.time()+300
  while time.time()<deadline:
   for name,offset in offsets.items():
    with (R/'logs'/f'{name}.log').open('rb') as f:f.seek(offset);data=f.read(4*1024*1024)
    if b'"event":"service.ready"' in data or b'"event": "service.ready"' in data:ready.add(name)
   if len(ready)==2:break
   time.sleep(1)
  assert ready=={'agent','worker'},'CUTOVER_SERVICE_NOT_READY'
  assert command(['systemctl','is-active','himawari.service']).stdout.strip()=='active'
  pid=command(['systemctl','show','himawari.service','-p','MainPID','--value']).stdout.strip()
  live=(pathlib.Path('/proc')/pid/'status').read_text()
  assert re.search(r'^Uid:\s+998\s+998\s+998\s+998$',live,re.M) and re.search(r'^NoNewPrivs:\s+1$',live,re.M)
  publish('resume.json',{'passed':True,'deploymentComplete':True,'schemaSequence':48,'migratedFrom':32,'runtimeDigest':qualified['runtimeDigest'],'receiptDigest':qualified['receiptDigest'],'ready':sorted(ready),'runtimeUid':998,'mainPid':int(pid),'backupId':'before-c71adbd-2026-09-27','modelCalls':0,'realModelAcceptance':'not_run_no_model_calls','sourceCommit':'c71adbd5f23a88834512ad26112f587d6fa993b9','physicalPrefix':str(CANDIDATE),'capabilityDeclarationsUnchanged':False,'registryDeviation':'registry-deviation.json'})
  status('deployment_completed_public_browser_verification_pending')
 except BaseException as error:
  stopped=False
  if new_started:
   try:command(['systemctl','stop','himawari.service'],90);stopped=True
   except BaseException:pass
  publish('resume-exception.json',{'exceptionType':type(error).__name__,'messageCode':str(error) if re.fullmatch('[A-Z_]+',str(error)) else None,'newServiceStartAttempted':new_started,'stoppedAfterFailure':stopped,'oldServiceMustNotStartOnSchema48':True})
  status('resume_failed_review_preserved_evidence');raise

if __name__=='__main__':main()
