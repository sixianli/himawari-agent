import hashlib, json, pathlib, shutil, subprocess
B = pathlib.Path("/data/hermes/himawari/builds/2026-09-28-ddbdac7")
old = pathlib.Path("/opt/himawari/releases/2026-09-28-cda3824")
h = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
m = json.loads((B / "source-manifest.json").read_text())
for e in m["files"]:
    assert h(B / "source" / e["path"]) == e["sha256"], e["path"]
for p in (old / "share/control-center/assets").iterdir():
    target = B / "prefix/share/control-center/assets" / p.name
    assert p.is_file() and not p.is_symlink()
    if target.exists():
        assert h(target) == h(p)
    else:
        shutil.copyfile(p, target)
files = [{"path": str(p.relative_to(B / "prefix")), "sha256": h(p)} for p in sorted((B / "prefix").rglob("*")) if p.is_file()]
assert not any(p.is_symlink() for p in (B / "prefix").rglob("*"))
runtime = B / "prefix/lib/himawari-agent"
script = 'const {createRequire}=require("node:module");const r=createRequire(' + json.dumps(str(runtime / "package.json")) + ');r("@himawari-agent/platform-node").digestSandboxRuntime(' + json.dumps(str(runtime)) + ').then(x=>console.log(JSON.stringify(x)));'
digest = json.loads(subprocess.check_output([str(runtime / "pi-tools/bin/node"), "-e", script], text=True))
result = {"buildPassed": True, "commit": m["commit"], "sourceArchiveSha256": m["archiveSha256"], "prefixFiles": files, "runtimeDigest": digest, "staticFiles": {str(p.relative_to(B / "prefix/share/control-center")): h(p) for p in (B / "prefix/share/control-center").rglob("*") if p.is_file()}}
(B / "preparation.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in ("prefixFiles", "staticFiles")}))
