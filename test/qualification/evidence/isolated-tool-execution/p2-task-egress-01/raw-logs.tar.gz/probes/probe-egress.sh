#!/bin/bash
# usage: probe-egress.sh <docker args...>
set -u
D=("$@")
IMG=docker.io/library/busybox@sha256:bdf57e528e45e4433820e045b29b4597825a1c9e38353532d90a01445013f82e
L=io.himawari.environment.run=probe-egress
NET=himawari-probe-internal
cleanup() { "${D[@]}" rm -f probe-proxy >/dev/null 2>&1; "${D[@]}" network rm $NET >/dev/null 2>&1; }
cleanup
"${D[@]}" network create --internal --label $L $NET >/dev/null
echo "== network"; "${D[@]}" network inspect $NET --format '{{json .IPAM.Config}} ipv6={{.EnableIPv6}} internal={{.Internal}}'
"${D[@]}" run -d --name probe-proxy --label $L --network $NET $IMG sh -c 'while :; do echo PROXY-OK | nc -l -p 3128; done' >/dev/null
"${D[@]}" network connect bridge probe-proxy
GW=$("${D[@]}" network inspect $NET --format '{{(index .IPAM.Config 0).Gateway}}')
echo "gateway=$GW"
echo "== proxy container can reach outside?"; "${D[@]}" exec probe-proxy sh -c 'wget -q -T 5 -O /dev/null http://example.com && echo proxy_out=open || echo proxy_out=blocked'
echo "== task"
"${D[@]}" run --rm --label $L --network $NET --user 65534:65534 --cap-drop ALL --security-opt no-new-privileges=true -e GW="$GW" $IMG sh -c '
echo "--- addr"; ip -o addr | awk "{print \$2, \$4}"
echo "--- route"; ip route; ip -6 route 2>&1
echo "--- resolv"; cat /etc/resolv.conf | grep -v "^#"
echo "dns_embedded_external=$(nslookup -timeout=3 example.com 2>&1 | grep -c "Address: [0-9a-f]" )"
echo "dns_embedded_proxyname=$(nslookup -timeout=3 probe-proxy 2>&1 | grep -c "Address: [0-9]")"
echo "dns_embedded_hostdocker=$(nslookup -timeout=3 host.docker.internal 2>&1 | grep "Address" | tail -1)"
echo "dns_direct_8888=$(nslookup -timeout=3 example.com 8.8.8.8 >/dev/null 2>&1 && echo open || echo blocked)"
echo "tcp_1111=$(wget -q -T 3 -O /dev/null http://1.1.1.1 2>/dev/null && echo open || echo blocked)"
echo "tcp_v6=$(wget -q -T 3 -O /dev/null "http://[2606:4700:4700::1111]" 2>/dev/null && echo open || echo blocked)"
echo "tcp_metadata=$(wget -q -T 3 -O /dev/null http://169.254.169.254 2>/dev/null && echo open || echo blocked)"
echo "tcp_gateway_22=$(nc -w 3 $GW 22 </dev/null >/dev/null 2>&1 && echo open || echo blocked)"
echo "tcp_gateway_80=$(nc -w 3 $GW 80 </dev/null >/dev/null 2>&1 && echo open || echo blocked)"
echo "tcp_hostdocker_22=$(nc -w 3 host.docker.internal 22 </dev/null >/dev/null 2>&1 && echo open || echo blocked)"
echo "udp_8888=$( (echo x | nc -u -w 2 8.8.8.8 53) >/dev/null 2>&1; echo rc$?)"
echo "proxy=$(nc -w 3 probe-proxy 3128 </dev/null)"
'
cleanup
echo "leftover=$("${D[@]}" ps -aq --filter label=$L | wc -l) networks=$("${D[@]}" network ls -q --filter label=$L | wc -l)"
