import json,pathlib,sqlite3,subprocess,hashlib,datetime
R=pathlib.Path('/data/hermes/himawari'); B=R/'builds/2026-09-16-v4-0600b29'; W=R/'qualifications/2026-09-16-v4-0600b29-cutover'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((B/'source-manifest.json').read_text());p=json.loads((B/'preparation.json').read_text());r=json.loads((W/'result.json').read_text())
assert m['commit']==p['commit']==r['sourceCommit']=='0600b2958432a4592a52e5c01cf92794a7af7121'
assert h(B/'source.tar.gz')==m['archiveSha256']==p['sourceArchiveSha256']
assert r['passed'] and r['deploymentComplete'] and r['runtimeDigest']==p['runtimeDigest']
assert json.loads(pathlib.Path('/etc/himawari/runtime.json').read_text())['runtimeDigest']==r['runtimeDigest']
before=json.loads((W/'private/production-before.json').read_text());after=json.loads((R/'config/production.json').read_text())
changed=sorted(k for k in before.keys()|after.keys() if before.get(k)!=after.get(k));assert changed==['capabilityDeployment'],changed
pid=subprocess.check_output(['systemctl','show','himawari','-p','MainPID','--value'],text=True).strip()
physical=pathlib.Path('/opt/himawari/releases/2026-09-16-v4-0600b29');mounted=pathlib.Path('/proc')/pid/'root/data/hermes/himawari/releases/2026-09-11-control-center'
assert (mounted.stat().st_dev,mounted.stat().st_ino)==(physical.stat().st_dev,physical.stat().st_ino)
with sqlite3.connect('file:'+str(R/'state/data/product.sqlite')+'?mode=ro',uri=True) as db:
 active=db.execute("select id,status from runs where status not in ('completed','failed','cancelled')").fetchall()
 unresolved=sum(1 for (v,) in db.execute('select facts_json from sandbox_execution_records') if (lambda x:x.get('resource',{}).get('cleanup')!='confirmed' or x.get('resource',{}).get('supervision')!='released')(json.loads(v)))
 fk=db.execute('pragma foreign_key_check').fetchall();schema=db.execute('select max(sequence) from schema_migration_ledger').fetchone()[0]
 assert not active and not unresolved and not fk and schema==32
assert json.loads((W/'backup-verify.json').read_text())['fullIntegrityCheck']=='ok'
static=[]
for name,digest in p['staticFiles'].items():
 content=subprocess.check_output(['curl','-fsS','--max-time','15','-H','Host: himawari.siyi.win','http://127.0.0.1:18082/'+('' if name=='index.html' else name)])
 assert hashlib.sha256(content).hexdigest()==digest,name
 static.append(name)
health=json.loads(subprocess.check_output(['curl','-fsS','--max-time','15','http://127.0.0.1:18082/health/ready'],text=True))
print(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':m['commit'],'runtimeDigest':r['runtimeDigest'],'livePhysicalMountVerified':True,'configChangedTopLevelKeys':changed,'schema':schema,'activeRuns':active,'unresolvedSandboxRecords':unresolved,'foreignKeyErrors':len(fk),'health':health,'modelCallsByDeployment':0,'httpStaticFilesMatched':len(static),'backupVerified':True},indent=2))
