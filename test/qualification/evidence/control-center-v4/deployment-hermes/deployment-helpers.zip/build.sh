#!/bin/bash
set -euo pipefail
umask 077
B=/data/hermes/himawari/builds/2026-09-16-v4-0600b29
TOOLS=/data/hermes/himawari/builds/2026-09-14-ci-complete-repair/source/.ci-output/security-tools
export PATH="$TOOLS/bin:/usr/bin:/bin"
export TMPDIR="$B/tmp"
export HIMAWARI_CI_PYTHON="$TOOLS/python/python/bin/python3"
cd "$B"
mkdir source tmp
tar -xzf source.tar.gz -C source
cd source
node scripts/ci/install-dependencies.mjs --tools "$TOOLS" --evidence .ci-output/installation --cache .ci-output/npm-cache > "$B/dependencies.log" 2>&1
node "$TOOLS/npm/package/bin/npm-cli.js" run build > "$B/build.log" 2>&1
node scripts/install-node-runtime.mjs --prefix "$B/prefix" > "$B/install.log" 2>&1
cp -a /opt/himawari/releases/2026-09-15-main-4f1e86f/lib/himawari-agent/pi-tools "$B/prefix/lib/himawari-agent/pi-tools"
mkdir -p "$B/prefix/share"
cp -a apps/control-center/dist "$B/prefix/share/control-center"
python3 "$B/finalize.py"
