import sqlite3,json
with sqlite3.connect('file:/data/hermes/himawari/state/data/product.sqlite?mode=ro',uri=True) as db:
 tables=[r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")]
 names=[n for n in tables if n in ('threads','runs','messages','thread_messages','run_payload_artifacts','payloads','thread_fork_lineage')]
 print(json.dumps({n:db.execute('SELECT count(*) FROM "'+n+'"').fetchone()[0] for n in names}))
