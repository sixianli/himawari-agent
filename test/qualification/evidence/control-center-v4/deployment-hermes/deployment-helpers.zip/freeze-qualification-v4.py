import os,pathlib,hashlib,json,stat
assert os.geteuid()==0
B=pathlib.Path('/data/hermes/himawari/builds/2026-09-16-v4-0600b29')
D=pathlib.Path('/etc/himawari/deploy-v4-0600b29')
manifest=json.loads((B/'helper-inputs.json').read_text())
assert not D.exists()
inputs={}
for name,digest in manifest.items():
 assert pathlib.Path(name).name==name
 p=B/name;assert p.is_file() and not p.is_symlink() and p.stat().st_nlink==1
 b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==digest;inputs[name]=b
D.mkdir(mode=0o755)
for name,data in inputs.items():
 p=D/name;p.write_bytes(data);p.chmod(0o644)
(D/'helper-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n');(D/'helper-inputs.json').chmod(0o644)
print(json.dumps({'frozenDirectory':str(D),'files':len(inputs)}))
